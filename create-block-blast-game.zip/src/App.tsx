import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  SIZE,
  applyMove,
  canPlace,
  emptyGrid,
  generatePieces,
  hasMove,
  type Grid,
  type Piece,
} from "./game/logic";
import { Block, PALETTE, PieceView } from "./components/Block";
import * as sfx from "./game/sound";

/* ------------------------------------------------------------------ */
/* Types & helpers                                                     */
/* ------------------------------------------------------------------ */

interface GameState {
  grid: Grid;
  pieces: (Piece | null)[];
  score: number;
  combo: number;
  sinceClear: number;
  over: boolean;
  startBest: number;
  moves: number;
}

interface DragState {
  index: number;
  x: number;
  y: number;
  touch: boolean;
  target: { row: number; col: number } | null;
}

interface Burst {
  id: number;
  cells: { r: number; c: number; color: number; delay: number }[];
  particles: {
    r: number;
    c: number;
    color: number;
    dx: number;
    dy: number;
    rot: number;
    delay: number;
    size: number;
  }[];
}

interface Popup {
  id: number;
  title: string;
  points: string;
  sub?: string;
}

const BEST_KEY = "blockblast-best";

const loadBest = () => {
  try {
    return Number(localStorage.getItem(BEST_KEY)) || 0;
  } catch {
    return 0;
  }
};

function newGame(startBest: number): GameState {
  const grid = emptyGrid();
  return {
    grid,
    pieces: generatePieces(grid),
    score: 0,
    combo: 0,
    sinceClear: 0,
    over: false,
    startBest,
    moves: 0,
  };
}

function floatPos(
  piece: Piece,
  x: number,
  y: number,
  touch: boolean,
  size: number
) {
  const w = piece.w * size;
  const h = piece.h * size;
  return {
    left: x - w / 2,
    top: touch ? y - h - size * 1.5 : y - h / 2 - size * 0.2,
  };
}

function useCountUp(target: number) {
  const [value, setValue] = useState(target);
  const current = useRef(target);
  useEffect(() => {
    const from = current.current;
    if (from === target) return;
    const start = performance.now();
    const dur = Math.min(700, 250 + Math.abs(target - from) * 4);
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      const v = Math.round(from + (target - from) * eased);
      current.current = v;
      setValue(v);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target]);
  return value;
}

/* ------------------------------------------------------------------ */
/* Kleine UI-onderdelen                                                */
/* ------------------------------------------------------------------ */

function IconButton({
  onClick,
  label,
  children,
}: {
  onClick: () => void;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-white/90 ring-1 ring-white/10 transition hover:bg-white/20 active:scale-95"
    >
      {children}
    </button>
  );
}

function Logo() {
  const cells = [1, 6, 2, 4];
  return (
    <div className="grid h-9 w-9 grid-cols-2 gap-[2px]">
      {cells.map((c, i) => (
        <Block key={i} color={c} className="h-full w-full" />
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* App                                                                 */
/* ------------------------------------------------------------------ */

export default function App() {
  const [state, setState] = useState<GameState>(() => newGame(loadBest()));
  const stateRef = useRef(state);

  const [best, setBest] = useState(loadBest);
  const [drag, setDrag] = useState<DragState | null>(null);
  const dragRef = useRef<DragState | null>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const [cs, setCs] = useState(0);

  const [bursts, setBursts] = useState<Burst[]>([]);
  const [popups, setPopups] = useState<Popup[]>([]);
  const [placed, setPlaced] = useState<Set<number>>(() => new Set());
  const [shake, setShake] = useState(false);
  const [muted, setMutedState] = useState(sfx.isMuted());
  const [showOver, setShowOver] = useState(false);
  const [confirmRestart, setConfirmRestart] = useState(false);
  const [bumpKey, setBumpKey] = useState(0);
  const idRef = useRef(1);

  stateRef.current = state;

  /* ---- Meten van de celgrootte ---- */
  useLayoutEffect(() => {
    const el = gridRef.current;
    if (!el) return;
    const measure = () => setCs(el.offsetWidth / SIZE);
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    window.addEventListener("resize", measure);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, []);

  /* ---- Beste score bijhouden ---- */
  useEffect(() => {
    if (state.score > best) setBest(state.score);
  }, [state.score, best]);

  useEffect(() => {
    try {
      localStorage.setItem(BEST_KEY, String(best));
    } catch {
      /* ignore */
    }
  }, [best]);

  /* ---- Game over ---- */
  useEffect(() => {
    if (!state.over) {
      setShowOver(false);
      return;
    }
    const t = setTimeout(() => {
      setShowOver(true);
      sfx.over();
    }, 900);
    return () => clearTimeout(t);
  }, [state.over]);

  /* ---- Slepen ---- */
  const updateDrag = useCallback((next: DragState | null) => {
    dragRef.current = next;
    setDrag(next);
  }, []);

  const makeDrag = useCallback(
    (index: number, x: number, y: number, touch: boolean): DragState => {
      const piece = stateRef.current.pieces[index];
      const el = gridRef.current;
      let target: DragState["target"] = null;
      if (piece && el) {
        const rect = el.getBoundingClientRect();
        const size = rect.width / SIZE;
        const { left, top } = floatPos(piece, x, y, touch, size);
        target = {
          row: Math.round((top - rect.top) / size),
          col: Math.round((left - rect.left) / size),
        };
      }
      return { index, x, y, touch, target };
    },
    []
  );

  const place = useCallback((index: number, row: number, col: number) => {
    const st = stateRef.current;
    const piece = st.pieces[index];
    if (!piece || st.over || !canPlace(st.grid, piece.shape, row, col)) {
      return false;
    }

    const res = applyMove(st.grid, piece, row, col);
    const lines = res.rows.length + res.cols.length;

    let combo = st.combo;
    let since = st.sinceClear;
    let gained = piece.size;
    let clearPoints = 0;

    if (lines > 0) {
      combo += 1;
      since = 0;
      clearPoints = 20 * lines * lines * Math.max(1, combo);
      if (res.perfect) clearPoints += 300;
      gained += clearPoints;
    } else {
      since += 1;
      if (since >= 3) combo = 0;
    }

    const rest = st.pieces.slice();
    rest[index] = null;
    const nextPieces = rest.every((p) => p === null)
      ? generatePieces(res.grid)
      : rest;
    const over = !nextPieces.some((p) => p && hasMove(res.grid, p.shape));

    const next: GameState = {
      ...st,
      grid: res.grid,
      pieces: nextPieces,
      score: st.score + gained,
      combo,
      sinceClear: since,
      over,
      moves: st.moves + 1,
    };
    stateRef.current = next;
    setState(next);

    /* Effecten */
    const placedKeys = new Set<number>();
    piece.shape.forEach((line, i) =>
      line.forEach((v, j) => {
        if (v) placedKeys.add((row + i) * SIZE + (col + j));
      })
    );
    setPlaced(placedKeys);
    setTimeout(() => setPlaced(new Set()), 320);

    if (lines > 0) {
      sfx.clear(lines, combo);
      const cr = row + (piece.h - 1) / 2;
      const cc = col + (piece.w - 1) / 2;
      const id = idRef.current++;
      const burst: Burst = {
        id,
        cells: res.cleared.map(({ r, c, color }) => ({
          r,
          c,
          color,
          delay: Math.round((Math.abs(r - cr) + Math.abs(c - cc)) * 28),
        })),
        particles: res.cleared.flatMap(({ r, c, color }) => {
          const delay = Math.round((Math.abs(r - cr) + Math.abs(c - cc)) * 28);
          return [0, 1].map(() => {
            const angle = Math.random() * Math.PI * 2;
            const dist = 30 + Math.random() * 50;
            return {
              r,
              c,
              color,
              dx: Math.cos(angle) * dist,
              dy: Math.sin(angle) * dist - 10,
              rot: (Math.random() - 0.5) * 540,
              delay,
              size: 5 + Math.random() * 5,
            };
          });
        }),
      };
      setBursts((b) => [...b, burst]);
      setTimeout(() => setBursts((b) => b.filter((x) => x.id !== id)), 1500);

      const title = res.perfect
        ? "Perfecte clear!"
        : lines >= 4
        ? "Fantastisch!"
        : lines === 3
        ? "Geweldig!"
        : lines === 2
        ? "Mooi!"
        : combo > 1
        ? "Combo!"
        : "Goed zo!";
      const popId = idRef.current++;
      setPopups((p) => [
        ...p,
        {
          id: popId,
          title,
          points: `+${clearPoints}`,
          sub: combo > 1 ? `Combo ×${combo}` : undefined,
        },
      ]);
      setTimeout(
        () => setPopups((p) => p.filter((x) => x.id !== popId)),
        1300
      );
      setBumpKey((k) => k + 1);

      if (lines >= 3 || res.perfect) {
        setShake(true);
        setTimeout(() => setShake(false), 450);
      }
    } else {
      sfx.place();
    }
    return true;
  }, []);

  const dragging = drag !== null;

  useEffect(() => {
    if (!dragging) return;
    const move = (e: PointerEvent) => {
      const d = dragRef.current;
      if (!d) return;
      updateDrag(makeDrag(d.index, e.clientX, e.clientY, d.touch));
    };
    const up = (e: PointerEvent) => {
      const d = dragRef.current;
      if (d) {
        const final = makeDrag(d.index, e.clientX, e.clientY, d.touch);
        if (final.target) place(d.index, final.target.row, final.target.col);
      }
      updateDrag(null);
    };
    const cancel = () => updateDrag(null);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", cancel);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", cancel);
    };
  }, [dragging, makeDrag, place, updateDrag]);

  const startDrag = (e: React.PointerEvent, index: number) => {
    const st = stateRef.current;
    if (!st.pieces[index] || st.over) return;
    if (e.pointerType === "mouse" && e.button !== 0) return;
    e.preventDefault();
    sfx.unlock();
    sfx.pick();
    updateDrag(
      makeDrag(index, e.clientX, e.clientY, e.pointerType !== "mouse")
    );
  };

  /* ---- Herstart ---- */
  const restart = () => {
    const g = newGame(best);
    stateRef.current = g;
    setState(g);
    setBursts([]);
    setPopups([]);
    setPlaced(new Set());
    setShowOver(false);
    setConfirmRestart(false);
    updateDrag(null);
  };

  const requestRestart = () => {
    sfx.unlock();
    if (state.score > 0 && !state.over) setConfirmRestart(true);
    else restart();
  };

  const toggleMute = () => {
    sfx.unlock();
    const next = !muted;
    sfx.setMuted(next);
    setMutedState(next);
  };

  /* ---- Afgeleide data ---- */
  const dragPiece = drag ? state.pieces[drag.index] : null;

  const preview = useMemo(() => {
    if (!drag || !drag.target) return null;
    const piece = state.pieces[drag.index];
    if (!piece) return null;
    const { row, col } = drag.target;
    if (!canPlace(state.grid, piece.shape, row, col)) return null;
    const ghost = new Set<number>();
    piece.shape.forEach((line, i) =>
      line.forEach((v, j) => {
        if (v) ghost.add((row + i) * SIZE + (col + j));
      })
    );
    const res = applyMove(state.grid, piece, row, col);
    const lines = new Set(res.cleared.map((c) => c.r * SIZE + c.c));
    return { ghost, lines, color: piece.color };
  }, [drag, state.grid, state.pieces]);

  const fits = useMemo(
    () =>
      state.pieces.map((p) => (p ? hasMove(state.grid, p.shape) : false)),
    [state.pieces, state.grid]
  );

  const shownScore = useCountUp(state.score);
  const displayBest = Math.max(best, state.score);
  const isRecord = state.score > 0 && state.score >= displayBest && state.score > state.startBest;

  const trayCell = cs * 0.48;
  const slotHeight = cs ? cs * 2.7 : 96;

  /* ---------------------------------------------------------------- */
  /* Render                                                            */
  /* ---------------------------------------------------------------- */

  const cells = [];
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const key = r * SIZE + c;
      const value = state.grid[r][c];
      const isGhost = preview?.ghost.has(key) ?? false;
      const isLine = preview?.lines.has(key) ?? false;

      let content;
      if (isGhost && preview) {
        content = (
          <Block
            color={preview.color}
            className={`h-full w-full ${isLine ? "anim-line" : ""}`}
            style={{ opacity: isLine ? 1 : 0.6 }}
          />
        );
      } else if (value && isLine && preview) {
        content = (
          <Block color={preview.color} className="anim-line h-full w-full" />
        );
      } else if (value) {
        content = (
          <Block
            color={value}
            className={`h-full w-full ${placed.has(key) ? "anim-pop" : ""}`}
          />
        );
      } else {
        content = (
          <div
            className="h-full w-full rounded-[18%]"
            style={{
              background: (r + c) % 2 === 0 ? "#18215c" : "#1b2664",
              boxShadow: "inset 0 1px 2px rgba(0,0,0,.35)",
            }}
          />
        );
      }

      cells.push(
        <div key={key} className="aspect-square p-[3%]">
          {content}
        </div>
      );
    }
  }

  const floating =
    drag && dragPiece && cs > 0
      ? floatPos(dragPiece, drag.x, drag.y, drag.touch, cs)
      : null;

  return (
    <div
      className="relative flex min-h-dvh w-full flex-col items-center justify-center overflow-x-hidden px-2 py-3 text-white"
      style={{
        background:
          "radial-gradient(1200px 600px at 50% -10%, #3a3fa8 0%, rgba(58,63,168,0) 60%), radial-gradient(800px 500px at 100% 100%, #5b2a9b55 0%, transparent 60%), linear-gradient(180deg, #151a54 0%, #0d1240 55%, #080b2a 100%)",
      }}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div
        className="flex flex-col gap-3"
        style={{ width: "min(94vw, 440px, 50dvh)", minWidth: 290 }}
      >
        {/* Titel + knoppen */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Logo />
            <h1 className="bg-gradient-to-r from-amber-200 via-orange-300 to-pink-400 bg-clip-text text-2xl font-black tracking-wide text-transparent drop-shadow-sm">
              BLOCK BLAST
            </h1>
          </div>
          <div className="flex gap-2">
            <IconButton
              onClick={toggleMute}
              label={muted ? "Geluid aanzetten" : "Geluid uitzetten"}
            >
              {muted ? (
                <svg
                  viewBox="0 0 24 24"
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M11 5 6 9H2v6h4l5 4V5z" />
                  <path d="m22 9-6 6" />
                  <path d="m16 9 6 6" />
                </svg>
              ) : (
                <svg
                  viewBox="0 0 24 24"
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M11 5 6 9H2v6h4l5 4V5z" />
                  <path d="M15.5 8.5a5 5 0 0 1 0 7" />
                  <path d="M19 5a10 10 0 0 1 0 14" />
                </svg>
              )}
            </IconButton>
            <IconButton onClick={requestRestart} label="Opnieuw beginnen">
              <svg
                viewBox="0 0 24 24"
                className="h-5 w-5"
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M3 12a9 9 0 1 0 3-6.7" />
                <path d="M3 4v5h5" />
              </svg>
            </IconButton>
          </div>
        </div>

        {/* Scorebord */}
        <div className="flex items-stretch gap-2">
          <div className="flex flex-[1.5] flex-col items-center justify-center rounded-2xl bg-white/10 px-3 py-2 ring-1 ring-white/10">
            <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/60">
              Score
            </span>
            <span
              key={bumpKey}
              className={`text-4xl font-black leading-none tabular-nums ${
                bumpKey ? "anim-bump" : ""
              }`}
            >
              {shownScore}
            </span>
          </div>
          <div className="flex flex-1 flex-col items-center justify-center rounded-2xl bg-white/10 px-2 py-2 ring-1 ring-white/10">
            <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-[0.2em] text-amber-300/90">
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="currentColor">
                <path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5L3 8z" />
              </svg>
              Beste
            </span>
            <span className="text-2xl font-extrabold leading-tight tabular-nums text-amber-200">
              {displayBest}
            </span>
          </div>
          <div
            className={`flex flex-1 flex-col items-center justify-center rounded-2xl px-2 py-2 ring-1 transition-colors ${
              state.combo >= 2
                ? "anim-combo bg-orange-500/25 ring-orange-400/60"
                : "bg-white/10 ring-white/10"
            }`}
          >
            <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/60">
              Combo
            </span>
            <span
              className={`text-2xl font-extrabold leading-tight tabular-nums ${
                state.combo >= 2 ? "text-orange-300" : "text-white/90"
              }`}
            >
              {state.combo > 0 ? `×${state.combo}` : "–"}
            </span>
            <div className="mt-0.5 flex gap-1">
              {[0, 1, 2].map((i) => (
                <span
                  key={i}
                  className={`h-1.5 w-1.5 rounded-full transition-colors ${
                    state.combo > 0 && i < 3 - state.sinceClear
                      ? "bg-orange-300"
                      : "bg-white/20"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Speelveld */}
        <div
          className={`relative rounded-2xl p-1.5 ${shake ? "anim-shake" : ""}`}
          style={{
            background: "linear-gradient(180deg, #0f1650 0%, #0a0f3a 100%)",
            boxShadow:
              "0 0 0 3px #2f3d9e, 0 0 0 5px rgba(255,255,255,.06), 0 24px 50px rgba(0,0,0,.55), inset 0 2px 8px rgba(0,0,0,.5)",
          }}
        >
          <div ref={gridRef} className="relative grid grid-cols-8">
            {cells}

            {/* Effecten bij wissen */}
            {bursts.map((b) => (
              <div
                key={b.id}
                className="pointer-events-none absolute inset-0 z-10"
              >
                {b.cells.map((cell) => (
                  <div
                    key={`c-${cell.r}-${cell.c}`}
                    className="absolute"
                    style={{
                      left: `${cell.c * 12.5}%`,
                      top: `${cell.r * 12.5}%`,
                      width: "12.5%",
                      height: "12.5%",
                    }}
                  >
                    <div className="h-full w-full p-[3%]">
                      <Block
                        color={cell.color}
                        className="anim-burst h-full w-full"
                        style={{ animationDelay: `${cell.delay}ms` }}
                      />
                    </div>
                  </div>
                ))}
                {b.particles.map((p, i) => (
                  <div
                    key={`p-${i}`}
                    className="anim-particle absolute"
                    style={
                      {
                        left: `${(p.c + 0.5) * 12.5}%`,
                        top: `${(p.r + 0.5) * 12.5}%`,
                        width: p.size,
                        height: p.size,
                        borderRadius: 2,
                        background: PALETTE[p.color]?.light,
                        boxShadow: `0 0 8px ${PALETTE[p.color]?.base}`,
                        animationDelay: `${p.delay}ms`,
                        "--dx": `${p.dx}px`,
                        "--dy": `${p.dy}px`,
                        "--rot": `${p.rot}deg`,
                      } as React.CSSProperties
                    }
                  />
                ))}
              </div>
            ))}

            {/* Pop-ups met punten */}
            {popups.map((p) => (
              <div
                key={p.id}
                className="anim-float-up pointer-events-none absolute left-1/2 top-[34%] z-20 whitespace-nowrap text-center"
              >
                <div
                  className="bg-gradient-to-b from-yellow-100 to-amber-400 bg-clip-text text-4xl font-black text-transparent"
                  style={{
                    filter: "drop-shadow(0 3px 0 rgba(120,53,15,.8)) drop-shadow(0 6px 10px rgba(0,0,0,.5))",
                  }}
                >
                  {p.title}
                </div>
                <div
                  className="text-3xl font-black text-white"
                  style={{ textShadow: "0 3px 0 rgba(0,0,0,.45)" }}
                >
                  {p.points}
                </div>
                {p.sub && (
                  <div className="mt-0.5 inline-block rounded-full bg-orange-500 px-3 py-0.5 text-sm font-extrabold shadow-lg">
                    {p.sub}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Blokken-lade */}
        <div className="grid grid-cols-3 gap-2">
          {state.pieces.map((piece, i) => {
            const isDragged = drag?.index === i;
            const canUse = piece ? fits[i] : false;
            return (
              <div
                key={i}
                className={`flex touch-none items-center justify-center rounded-2xl bg-white/[0.06] ring-1 ring-white/10 ${
                  piece ? "cursor-grab active:cursor-grabbing" : ""
                }`}
                style={{ height: slotHeight }}
                onPointerDown={(e) => startDrag(e, i)}
              >
                {piece && (
                  <div
                    style={{
                      opacity: isDragged ? 0 : canUse ? 1 : 0.35,
                      filter: canUse ? undefined : "grayscale(0.7)",
                    }}
                  >
                    <div
                      key={piece.uid}
                      className="anim-slide-in"
                      style={{ animationDelay: `${i * 70}ms` }}
                    >
                      <PieceView piece={piece} cell={trayCell} />
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <p className="text-center text-xs text-white/40">
          Sleep de blokken naar het speelveld en maak rijen of kolommen vol.
        </p>
      </div>

      {/* Zwevend blok tijdens slepen */}
      {floating && dragPiece && (
        <div
          className="pointer-events-none fixed left-0 top-0 z-50"
          style={{
            transform: `translate3d(${floating.left}px, ${floating.top}px, 0)`,
            willChange: "transform",
          }}
        >
          <div
            className="anim-pickup"
            style={{ filter: "drop-shadow(0 14px 10px rgba(0,0,0,.45))" }}
          >
            <PieceView piece={dragPiece} cell={cs} />
          </div>
        </div>
      )}

      {/* Bevestiging herstarten */}
      {confirmRestart && (
        <div className="anim-fade fixed inset-0 z-40 flex items-center justify-center bg-black/60 p-6 backdrop-blur-sm">
          <div className="anim-modal w-full max-w-xs rounded-3xl bg-gradient-to-b from-[#2b3591] to-[#171d62] p-6 text-center shadow-2xl ring-1 ring-white/15">
            <h2 className="text-xl font-extrabold">Opnieuw beginnen?</h2>
            <p className="mt-1 text-sm text-white/65">
              Je huidige spel gaat verloren.
            </p>
            <div className="mt-5 flex gap-3">
              <button
                type="button"
                onClick={() => setConfirmRestart(false)}
                className="flex-1 rounded-xl bg-white/10 py-2.5 font-bold ring-1 ring-white/15 transition hover:bg-white/20 active:scale-95"
              >
                Annuleren
              </button>
              <button
                type="button"
                onClick={restart}
                className="flex-1 rounded-xl bg-gradient-to-b from-orange-400 to-rose-500 py-2.5 font-bold shadow-lg transition hover:brightness-110 active:scale-95"
              >
                Ja, opnieuw
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Game over */}
      {showOver && (
        <div className="anim-fade fixed inset-0 z-40 flex items-center justify-center bg-black/65 p-6 backdrop-blur-sm">
          <div className="anim-modal w-full max-w-sm rounded-3xl bg-gradient-to-b from-[#2f3a9c] to-[#171d62] p-7 text-center shadow-2xl ring-1 ring-white/20">
            <div className="mx-auto mb-3 grid h-14 w-14 grid-cols-2 gap-[3px]">
              {[1, 2, 3, 8].map((c, i) => (
                <Block key={i} color={c} className="h-full w-full" />
              ))}
            </div>
            <h2 className="text-3xl font-black tracking-wide">Game over</h2>
            {isRecord && (
              <div className="mt-2 inline-block rounded-full bg-gradient-to-r from-amber-300 to-orange-400 px-4 py-1 text-sm font-extrabold text-amber-950 shadow-lg">
                🏆 Nieuw record!
              </div>
            )}
            <div className="mt-5 grid grid-cols-2 gap-3">
              <div className="rounded-2xl bg-white/10 py-3 ring-1 ring-white/10">
                <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/60">
                  Score
                </div>
                <div className="text-3xl font-black tabular-nums">
                  {state.score}
                </div>
              </div>
              <div className="rounded-2xl bg-white/10 py-3 ring-1 ring-white/10">
                <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-amber-300/90">
                  Beste
                </div>
                <div className="text-3xl font-black tabular-nums text-amber-200">
                  {displayBest}
                </div>
              </div>
            </div>
            <p className="mt-3 text-sm text-white/60">
              Je plaatste {state.moves} blokken.
            </p>
            <button
              type="button"
              onClick={restart}
              className="mt-5 w-full rounded-2xl bg-gradient-to-b from-emerald-400 to-green-600 py-3 text-lg font-extrabold shadow-lg shadow-green-900/40 transition hover:brightness-110 active:scale-95"
            >
              Opnieuw spelen
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
