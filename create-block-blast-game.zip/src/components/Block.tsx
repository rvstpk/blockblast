import type { CSSProperties } from "react";
import type { Piece } from "../game/logic";

interface Tone {
  light: string;
  base: string;
  dark: string;
}

export const PALETTE: Record<number, Tone> = {
  1: { light: "#ff9a9a", base: "#ef4444", dark: "#b91c1c" },
  2: { light: "#ffc98a", base: "#f97316", dark: "#c2410c" },
  3: { light: "#fff08a", base: "#facc15", dark: "#ca8a04" },
  4: { light: "#9af5b5", base: "#22c55e", dark: "#15803d" },
  5: { light: "#a9f4ff", base: "#22d3ee", dark: "#0e7490" },
  6: { light: "#9cc8ff", base: "#3b82f6", dark: "#1d4ed8" },
  7: { light: "#cdb9ff", base: "#8b5cf6", dark: "#5b21b6" },
  8: { light: "#ffb0dc", base: "#ec4899", dark: "#9d174d" },
};

interface BlockProps {
  color: number;
  className?: string;
  style?: CSSProperties;
}

export function Block({ color, className = "", style }: BlockProps) {
  const tone = PALETTE[color] ?? PALETTE[1];
  return (
    <div
      className={className}
      style={{
        background: `linear-gradient(155deg, ${tone.light} 0%, ${tone.base} 48%, ${tone.dark} 100%)`,
        boxShadow:
          "inset 0 2px 1px rgba(255,255,255,.55), inset 2px 0 1px rgba(255,255,255,.18), inset 0 -3px 2px rgba(0,0,0,.28), 0 1px 3px rgba(0,0,0,.45)",
        borderRadius: "18%",
        ...style,
      }}
    />
  );
}

interface PieceViewProps {
  piece: Piece;
  cell: number;
  className?: string;
  style?: CSSProperties;
}

export function PieceView({ piece, cell, className = "", style }: PieceViewProps) {
  const pad = Math.max(1, cell * 0.04);
  return (
    <div
      className={className}
      style={{
        display: "grid",
        gridTemplateColumns: `repeat(${piece.w}, ${cell}px)`,
        gridAutoRows: `${cell}px`,
        ...style,
      }}
    >
      {piece.shape.flatMap((row, r) =>
        row.map((v, c) =>
          v ? (
            <div key={`${r}-${c}`} style={{ padding: pad }}>
              <Block color={piece.color} className="h-full w-full" />
            </div>
          ) : (
            <div key={`${r}-${c}`} />
          )
        )
      )}
    </div>
  );
}
