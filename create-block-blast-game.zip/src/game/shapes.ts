export type Shape = number[][];

const parse = (rows: string[]): Shape =>
  rows.map((r) => [...r].map((ch) => (ch === "#" ? 1 : 0)));

const rotate = (s: Shape): Shape => {
  const h = s.length;
  const w = s[0].length;
  const out: Shape = Array.from({ length: w }, () => Array(h).fill(0));
  for (let r = 0; r < h; r++) {
    for (let c = 0; c < w; c++) {
      out[c][h - 1 - r] = s[r][c];
    }
  }
  return out;
};

const mirror = (s: Shape): Shape => s.map((row) => [...row].reverse());

const keyOf = (s: Shape) => s.map((r) => r.join("")).join("|");

function variants(rows: string[], rot: boolean, mir: boolean): Shape[] {
  const seen = new Map<string, Shape>();
  const bases: Shape[] = [parse(rows)];
  if (mir) bases.push(mirror(bases[0]));
  for (const base of bases) {
    let cur = base;
    for (let i = 0; i < (rot ? 4 : 1); i++) {
      seen.set(keyOf(cur), cur);
      cur = rotate(cur);
    }
  }
  return [...seen.values()];
}

export interface ShapeGroup {
  id: string;
  color: number; // 1..8
  weight: number;
  variants: Shape[];
}

const g = (
  id: string,
  color: number,
  weight: number,
  rows: string[],
  opts: { rot?: boolean; mir?: boolean } = {}
): ShapeGroup => ({
  id,
  color,
  weight,
  variants: variants(rows, opts.rot ?? true, opts.mir ?? false),
});

export const GROUPS: ShapeGroup[] = [
  g("dot", 3, 1, ["#"]),
  g("i2", 5, 3, ["##"]),
  g("i3", 6, 4, ["###"]),
  g("i4", 7, 3, ["####"]),
  g("i5", 8, 2, ["#####"]),
  g("o2", 4, 4, ["##", "##"]),
  g("o3", 1, 2, ["###", "###", "###"]),
  g("r23", 2, 3, ["###", "###"]),
  g("l3", 3, 4, ["#.", "##"]),
  g("bigL", 1, 3, ["#..", "#..", "###"]),
  g("lj", 6, 4, ["#.", "#.", "##"], { mir: true }),
  g("t", 7, 3, ["###", ".#."]),
  g("sz", 4, 3, [".##", "##."], { mir: true }),
];
