let ctx: AudioContext | null = null;

const MUTE_KEY = "blockblast-muted";

let muted = (() => {
  try {
    return localStorage.getItem(MUTE_KEY) === "1";
  } catch {
    return false;
  }
})();

export const isMuted = () => muted;

export function setMuted(value: boolean) {
  muted = value;
  try {
    localStorage.setItem(MUTE_KEY, value ? "1" : "0");
  } catch {
    /* ignore */
  }
}

export function unlock() {
  if (!ctx) {
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext })
        .webkitAudioContext;
    if (AC) ctx = new AC();
  }
  if (ctx && ctx.state === "suspended") void ctx.resume();
}

function tone(
  freq: number,
  start: number,
  dur: number,
  type: OscillatorType = "sine",
  vol = 0.12,
  endFreq?: number
) {
  if (!ctx || muted) return;
  const t = ctx.currentTime + start;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  if (endFreq) osc.frequency.exponentialRampToValueAtTime(endFreq, t + dur);
  gain.gain.setValueAtTime(0.0001, t);
  gain.gain.exponentialRampToValueAtTime(vol, t + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(t);
  osc.stop(t + dur + 0.03);
}

const note = (semitones: number, base = 523.25) =>
  base * Math.pow(2, semitones / 12);

export function pick() {
  tone(440, 0, 0.07, "triangle", 0.07, 620);
}

export function place() {
  tone(220, 0, 0.12, "triangle", 0.16, 140);
  tone(330, 0.01, 0.08, "sine", 0.06);
}

export function clear(lines: number, combo: number) {
  const scale = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21];
  const count = Math.min(scale.length, 3 + lines + Math.min(combo, 3));
  const shift = Math.min(combo - 1, 5) * 1;
  for (let i = 0; i < count; i++) {
    tone(note(scale[i] + shift), i * 0.055, 0.22, "triangle", 0.13);
    tone(note(scale[i] + shift + 12), i * 0.055, 0.14, "sine", 0.04);
  }
  tone(110, 0, 0.25, "sine", 0.18, 60);
}

export function over() {
  const notes = [7, 4, 0, -5];
  notes.forEach((n, i) => {
    tone(note(n, 440), i * 0.2, 0.35, "sawtooth", 0.07, note(n, 440) * 0.9);
  });
}
