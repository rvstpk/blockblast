import { GROUPS, type Shape } from "./shapes";

export const SIZE = 8;

export type Grid = number[][];

export interface Piece {
  uid: number;
  shape: Shape;
  color: number;
  w: number;
  h: number;
  size: number; // aantal blokjes
}

export interface MoveResult {
  grid: Grid;
  rows: number[];
  cols: number[];
  cleared: { r: number; c: number; color: number }[];
  perfect: boolean;
}

let uidCounter = 1;

export const emptyGrid = (): Grid =>
  Array.from({ length: SIZE }, () => Array<number>(SIZE).fill(0));

export function canPlace(
  grid: Grid,
  shape: Shape,
  row: number,
  col: number
): boolean {
  for (let i = 0; i < shape.length; i++) {
    for (let j = 0; j < shape[i].length; j++) {
      if (!shape[i][j]) continue;
      const r = row + i;
      const c = col + j;
      if (r < 0 || c < 0 || r >= SIZE || c >= SIZE) return false;
      if (grid[r][c] !== 0) return false;
    }
  }
  return true;
}

export function hasMove(grid: Grid, shape: Shape): boolean {
  const h = shape.length;
  const w = shape[0].length;
  for (let r = 0; r <= SIZE - h; r++) {
    for (let c = 0; c <= SIZE - w; c++) {
      if (canPlace(grid, shape, r, c)) return true;
    }
  }
  return false;
}

export function applyMove(
  grid: Grid,
  piece: Pick<Piece, "shape" | "color">,
  row: number,
  col: number
): MoveResult {
  const next = grid.map((r) => r.slice());
  piece.shape.forEach((line, i) =>
    line.forEach((v, j) => {
      if (v) next[row + i][col + j] = piece.color;
    })
  );

  const rows: number[] = [];
  const cols: number[] = [];
  for (let r = 0; r < SIZE; r++) {
    if (next[r].every((v) => v !== 0)) rows.push(r);
  }
  for (let c = 0; c < SIZE; c++) {
    if (next.every((line) => line[c] !== 0)) cols.push(c);
  }

  const cleared: { r: number; c: number; color: number }[] = [];
  const seen = new Set<number>();
  const mark = (r: number, c: number) => {
    const k = r * SIZE + c;
    if (seen.has(k)) return;
    seen.add(k);
    cleared.push({ r, c, color: next[r][c] });
  };
  rows.forEach((r) => {
    for (let c = 0; c < SIZE; c++) mark(r, c);
  });
  cols.forEach((c) => {
    for (let r = 0; r < SIZE; r++) mark(r, c);
  });
  cleared.forEach(({ r, c }) => {
    next[r][c] = 0;
  });

  const perfect =
    cleared.length > 0 && next.every((line) => line.every((v) => v === 0));

  return { grid: next, rows, cols, cleared, perfect };
}

function pickGroup() {
  const total = GROUPS.reduce((s, g) => s + g.weight, 0);
  let n = Math.random() * total;
  for (const g of GROUPS) {
    n -= g.weight;
    if (n <= 0) return g;
  }
  return GROUPS[0];
}

export function randomPiece(): Piece {
  const group = pickGroup();
  const shape =
    group.variants[Math.floor(Math.random() * group.variants.length)];
  const size = shape.reduce((s, row) => s + row.reduce((a, b) => a + b, 0), 0);
  return {
    uid: uidCounter++,
    shape,
    color: group.color,
    w: shape[0].length,
    h: shape.length,
    size,
  };
}

/** Controleert of alle stukken in een bepaalde volgorde geplaatst kunnen worden. */
function solvable(grid: Grid, pieces: Piece[]): boolean {
  if (pieces.length === 0) return true;
  for (let i = 0; i < pieces.length; i++) {
    const p = pieces[i];
    const rest = pieces.filter((_, k) => k !== i);
    for (let r = 0; r <= SIZE - p.h; r++) {
      for (let c = 0; c <= SIZE - p.w; c++) {
        if (!canPlace(grid, p.shape, r, c)) continue;
        const res = applyMove(grid, p, r, c);
        if (solvable(res.grid, rest)) return true;
      }
    }
  }
  return false;
}

/** Geeft 3 nieuwe stukken, bij voorkeur zo dat ze alle drie geplaatst kunnen worden. */
export function generatePieces(grid: Grid): Piece[] {
  let pieces: Piece[] = [];
  for (let attempt = 0; attempt < 25; attempt++) {
    pieces = [randomPiece(), randomPiece(), randomPiece()];
    if (solvable(grid, pieces)) return pieces;
  }
  for (let attempt = 0; attempt < 40; attempt++) {
    pieces = [randomPiece(), randomPiece(), randomPiece()];
    if (pieces.some((p) => hasMove(grid, p.shape))) return pieces;
  }
  return pieces;
}
